package StudentManagement;
import java.util.*;
public class StudentDetails {
     public static void main(String[] args) { 
Scanner sc=new Scanner(System.in);
System.out.println("Enter your Enrollnumber");
int en=sc.nextInt();
System.out.println("Enter your Fullname:");
String sname=sc.next();
//Enter personal details
System.out.println("Your personam details:");
System.out.println("Enter your fathername:");
String fname=sc.next();
System.out.println("Enter your mothername:");
String mname=sc.next();
System.out.println("Enter your mobile number");
long mno=sc.nextLong();
System.out.println("Enter your Email id");
String email=sc.next();
//Education details
int x;
System.out.println("Select your year and sem:\n  1.1st year 1nd sem\n  2.1st year 2nd sem\n  3.2nd tear 1st sem\n  4.2nd year 2nd sem\n  5.3rd year 1st sem\n  6.3rd year 2nd sem");
x=sc.nextInt();
switch(x)
{
case 1:System.out.println("1st year 1nd sem");break;
case 2:System.out.println("1st year 2nd sem");break;
case 3:System.out.println("2st year 1nd sem");break;
case 4:System.out.println("2st year 2nd sem");break;
case 5:System.out.println("3st year 1nd sem");break;
case 6:System.out.println("3st year 2nd sem");break;
default:System.out.println("Please select correct year and semester");
}
//Course details
String sel;
System.out.println("Your course details:\n  1.B.Sc\n    a.MECS\n    b.BMC\n    c.MPCS\n    d.MSCS\n  2.B.Com\n    A.CA\n    B.Comerce\n  3.BBA\n  4.BA\nSelect your Course");
sel=sc.next();
double a=30000; double b=33000; double c=32000; double d=28000;
switch(sel)
{
case "a":System.out.println("Total fess per year(BSc-MECS):\n"+a+"/-");break;
case "b":System.out.println("Total fess per year(BSc-BMC):\n"+a+"/-");break;
case "c":System.out.println("Total fess per year(BSc-MPCS):\n"+a+"/-");break;	
case "d":System.out.println("Total fess per year(BSc-MSCS):\n"+a+"/-");break;
case "A": System.out.println("Total fess per year(B.Com-CA):\n"+b+"/-");break;
case "B": System.out.println("Total fess per year(B.Com-C0merce):\n"+b+"/-");break;
case "3": System.out.println("Total fess per year(BBA):\n"+c+"/-");break;
case "4": System.out.println("Total fess per year(B.A):\n"+d+"/-");break;
default:System.out.println("Invalid Choice");
}
//Checking Payment details
System.out.println("Paid fees:\n");double paidfees=sc.nextDouble();
System.out.println("Totalfees:\n");double totalfees=sc.nextDouble();
double balance=totalfees-paidfees;
if(balance!=0) 
{
	System.out.println("Balance fees:\n  "+balance+"/-");
	if(balance==totalfees)
	{
		System.out.println("You didn't paid anything,So please pay the fees as soon as possible.");
	}
 }
	else
	{
		System.out.println("Balance fees:\n  "+balance+"/-");
		System.out.println("You paid the total amount,there is no balnce fees.");
	}

	}}

